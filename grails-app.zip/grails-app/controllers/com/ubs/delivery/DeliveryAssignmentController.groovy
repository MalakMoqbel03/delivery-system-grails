package com.ubs.delivery

import grails.gorm.transactions.Transactional

class DeliveryAssignmentController {

    static allowedMethods = [save: "POST", delete: "DELETE"]

    def index() {
        def assignments = DeliveryAssignment.list(sort: 'assignedAt', order: 'desc')
        [assignmentList: assignments, assignmentCount: assignments.size()]
    }

    def create() {
        [
                warehouses: Warehouse.list(sort: 'name'),
                deliveryPoints: DeliveryPoint.list(sort: 'name'),
                assignment: new DeliveryAssignment()
        ]
    }
    @Transactional
    def save() {
        def warehouseId = params.long('warehouse.id')
        def deliveryPointId = params.long('deliveryPoint.id')
        def status = params.status

        def warehouse = Warehouse.get(warehouseId)
        def deliveryPoint = DeliveryPoint.get(deliveryPointId)

        if (!warehouse || !deliveryPoint) {
            flash.message = "Warehouse or Delivery Point not found"
            redirect action: 'create'
            return
        }

        def existing = DeliveryAssignment.findByWarehouseAndDeliveryPoint(warehouse, deliveryPoint)
        if (existing) {
            flash.message = "Assignment already exists for this pair"
            redirect action: 'create'
            return
        }

        def assignment = new DeliveryAssignment(
                warehouse: warehouse,
                deliveryPoint: deliveryPoint,
                status: status
        )

        if (!assignment.save(flush: true)) {
            transactionStatus.setRollbackOnly()
            flash.message = "Could not save: ${assignment.errors}"
            redirect action: 'create'
            return
        }

        flash.message = "Assignment created successfully"
        redirect action: 'index'
    }

    @Transactional
    def delete(Long id) {
        def assignment = DeliveryAssignment.get(id)
        if (!assignment) {
            flash.message = "Assignment not found"
            redirect action: 'index'
            return
        }

        assignment.delete(flush: true)
        flash.message = "Assignment deleted"
        redirect action: 'index'
    }
}