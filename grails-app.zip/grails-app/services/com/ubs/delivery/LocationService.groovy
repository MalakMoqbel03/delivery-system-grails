package com.ubs.delivery

import grails.gorm.transactions.Transactional


class LocationService {

    List<Location> list(params) {
        Location.list(params)
    }

    int count() {
        Location.count()
    }

    Location get(Long id) {
        Location.get(id)
    }

    Location save(Location location) {
        location.save(flush: true, failOnError: true)
    }

    void delete(Long id) {
        Location.get(id)?.delete(flush: true)
    }


    List<Location> getAllSortedByDistance() {
        return Location.list().sort { location ->
            Math.sqrt(location.x * location.x + location.y * location.y)
        }
    }

    List<DeliveryPoint> getHighPriorityDeliveries() {
        return DeliveryPoint.findAllByPriority('HIGH')
    }

    List<Warehouse> getWarehousesWithSpace() {
        return Warehouse.withCriteria {
            ltProperty('currentLoad', 'maxCapacity')
        }
    }

    @Transactional
    String getAIInsight(Location location) {
        String result

        if (location instanceof DeliveryPoint) {
            DeliveryPoint dp = (DeliveryPoint) location
            String timeAdvice = dp.priority == 'HIGH' ? 'Schedule immediately — this is urgent.'
                    : dp.priority == 'MEDIUM' ? 'Deliver within the next 24 hours.'
                    : 'Can be scheduled at your convenience.'

            result = "Delivery to ${dp.deliveryArea}: ${timeAdvice}"
        } else if (location instanceof Warehouse) {
            Warehouse wh = (Warehouse) location
            String status = wh.hasSpace() ? 'has space available' : 'is FULL'
            result = "Warehouse ${wh.name} ${status} (${wh.currentLoad}/${wh.maxCapacity})."
        } else {
            result = "General location ${location.name} at coordinates (${location.x}, ${location.y})."
        }

        new AIQueryLog(
                locationCode: location.code,
                locationName: location.name,
                queryType: location.class.simpleName,
                aiResponse: result
        ).save(flush: true, failOnError: true)

        return result
    }
}