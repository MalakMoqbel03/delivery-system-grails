<div style="max-width:500px;margin-top:24px;">
    <h3 style="color:#555;font-size:16px;margin-bottom:12px;">
        Assigned Delivery Points
    </h3>

    <g:if test="${warehouse?.assignments}">
        <table style="width:100%;border-collapse:collapse;background:white;
        border-radius:8px;box-shadow:0 2px 8px rgba(0,0,0,0.08);">
            <thead>
            <tr style="background:#f8f9fa;">
                <th style="padding:10px;text-align:left;color:#888;">Delivery Point</th>
                <th style="padding:10px;text-align:left;color:#888;">Status</th>
                <th style="padding:10px;text-align:left;color:#888;">Assigned At</th>
                <th style="padding:10px;"></th>
            </tr>
            </thead>
            <tbody>
            <g:each in="${warehouse.assignments}" var="a">
                <tr style="border-top:1px solid #eee;">
                    <td style="padding:10px;">
                        <g:link controller="deliveryPoint" action="show" id="${a.deliveryPoint.id}">
                            ${a.deliveryPoint.name}
                        </g:link>
                    </td>
                    <td style="padding:10px;">
                        <span style="color:${a.status == 'DELIVERED' ? '#27ae60' :
                                a.status == 'IN_TRANSIT' ? '#f39c12' : '#888'};
                        font-weight:bold;">
                            ${a.status}
                        </span>
                    </td>
                    <td style="padding:10px;color:#888;">
                        <g:formatDate date="${a.assignedAt}" format="yyyy-MM-dd"/>
                    </td>
                    <td style="padding:10px;">
                        <g:form controller="deliveryAssignment" action="delete"
                                method="DELETE" style="display:inline;">
                            <g:hiddenField name="id" value="${a.id}"/>
                            <button type="submit" style="color:#e74c3c;background:none;
                            border:none;cursor:pointer;"
                                    onclick="return confirm('Remove this assignment?')">
                                Remove
                            </button>
                        </g:form>
                    </td>
                </tr>
            </g:each>
            </tbody>
        </table>
    </g:if>
    <g:else>
        <p style="color:#aaa;font-style:italic;">No delivery points assigned yet.</p>
    </g:else>

    <div style="margin-top:12px;">
        <g:link controller="deliveryAssignment" action="create"
                class="btn btn-primary">+ Add Assignment</g:link>
    </div>
</div>