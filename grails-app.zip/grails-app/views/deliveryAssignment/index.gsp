<!DOCTYPE html>
<html>
<head>
    <meta name="layout" content="main"/>
    <title>Delivery Assignments</title>
    <asset:stylesheet src="delivery.css"/>
</head>
<body>

<h1>Delivery Assignments</h1>

<div class="nav-buttons">
    <g:link action="create" class="btn btn-primary">+ New Assignment</g:link>
</div>

<g:if test="${flash.message}">
    <div class="flash-message">${flash.message}</div>
</g:if>

<g:if test="${assignmentList}">
    <table style="width:100%;border-collapse:collapse;background:white;
    border-radius:8px;box-shadow:0 2px 8px rgba(0,0,0,0.08);margin-top:16px;">
        <thead>
        <tr style="background:#f8f9fa;">
            <th style="padding:12px;text-align:left;color:#888;">Warehouse</th>
            <th style="padding:12px;text-align:left;color:#888;">Delivery Point</th>
            <th style="padding:12px;text-align:left;color:#888;">Status</th>
            <th style="padding:12px;text-align:left;color:#888;">Assigned At</th>
            <th style="padding:12px;"></th>
        </tr>
        </thead>
        <tbody>
        <g:each in="${assignmentList}" var="a">
            <tr style="border-top:1px solid #eee;">
                <td style="padding:12px;">
                    <g:link controller="warehouse" action="show"
                            id="${a.warehouse.id}">${a.warehouse.name}</g:link>
                </td>
                <td style="padding:12px;">
                    <g:link controller="deliveryPoint" action="show"
                            id="${a.deliveryPoint.id}">${a.deliveryPoint.name}</g:link>
                </td>
                <td style="padding:12px;">
                    <span style="color:${a.status == 'DELIVERED' ? '#27ae60' :
                            a.status == 'IN_TRANSIT' ? '#f39c12' : '#888'};
                    font-weight:bold;">
                        ${a.status}
                    </span>
                </td>
                <td style="padding:12px;color:#888;">
                    <g:formatDate date="${a.assignedAt}" format="yyyy-MM-dd HH:mm"/>
                </td>
                <td style="padding:12px;">
                    <g:form controller="deliveryAssignment" action="delete"
                            method="DELETE" style="display:inline;">
                        <g:hiddenField name="id" value="${a.id}"/>
                        <button type="submit" class="btn btn-delete"
                                onclick="return confirm('Delete assignment: ${a}?')">
                            Delete
                        </button>
                    </g:form>
                </td>
            </tr>
        </g:each>
        </tbody>
    </table>
</g:if>
<g:else>
    <p style="color:#aaa;margin-top:20px;">No assignments yet. Create one above.</p>
</g:else>

</body>
</html>