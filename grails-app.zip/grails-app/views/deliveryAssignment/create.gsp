<!DOCTYPE html>
<html>
<head>
    <meta name="layout" content="main"/>
    <title>New Delivery Assignment</title>
    <asset:stylesheet src="delivery.css"/>
</head>
<body>

<h1>New Delivery Assignment</h1>

<div class="nav-buttons">
    <g:link action="index" class="btn btn-secondary">← Back to list</g:link>
</div>

<g:if test="${flash.message}">
    <div class="flash-message">${flash.message}</div>
</g:if>

<div style="background:white;padding:24px;border-radius:8px;
box-shadow:0 2px 8px rgba(0,0,0,0.08);max-width:500px;margin-top:16px;">

    <g:form action="save" method="POST">

        <div style="margin-bottom:16px;">
            <label style="display:block;color:#888;margin-bottom:6px;">Warehouse</label>
            <g:select name="warehouse.id"
                      from="${warehouses}"
                      optionKey="id"
                      optionValue="name"
                      noSelection="${['': '-- Select Warehouse --']}"
                      style="width:100%;padding:8px;border:1px solid #ddd;border-radius:4px;"/>
        </div>

        <div style="margin-bottom:16px;">
            <label style="display:block;color:#888;margin-bottom:6px;">Delivery Point</label>
            <g:select name="deliveryPoint.id"
                      from="${deliveryPoints}"
                      optionKey="id"
                      optionValue="name"
                      noSelection="${['': '-- Select Delivery Point --']}"
                      style="width:100%;padding:8px;border:1px solid #ddd;border-radius:4px;"/>
        </div>

        <div style="margin-bottom:20px;">
            <label style="display:block;color:#888;margin-bottom:6px;">Status</label>
            <g:select name="status"
                      from="${['PENDING','IN_TRANSIT','DELIVERED']}"
                      style="width:100%;padding:8px;border:1px solid #ddd;border-radius:4px;"/>
        </div>

        <button type="submit" class="btn btn-primary">Create Assignment</button>
    </g:form>
</div>

</body>
</html>