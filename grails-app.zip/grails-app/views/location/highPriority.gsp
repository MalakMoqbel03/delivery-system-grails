<!DOCTYPE html>
<html>
<head>
    <meta name="layout" content="main"/>
    <title>High Priority Delivery Points</title>
</head>
<body>
<div class="container mt-4">
    <h1>High Priority Delivery Points</h1>

    <g:if test="${flash.message}">
        <div class="alert alert-info" role="alert">
            ${flash.message}
        </div>
    </g:if>

    <g:if test="${highPriorityPoints && highPriorityPoints.size() > 0}">
        <table class="table table-bordered table-striped">
            <thead>
            <tr>
                <th>ID</th>
                <th>Code</th>
                <th>Name</th>
                <th>X</th>
                <th>Y</th>
                <th>Delivery Area</th>
                <th>Priority</th>
                <th>Actions</th>
            </tr>
            </thead>
            <tbody>
            <g:each in="${highPriorityPoints}" var="point">
                <tr>
                    <td>${point.id}</td>
                    <td>${point.code}</td>
                    <td>${point.name}</td>
                    <td>${point.x}</td>
                    <td>${point.y}</td>
                    <td>${point.deliveryArea}</td>
                    <td>${point.priority}</td>
                    <td>
                        <g:link controller="location" action="show" id="${point.id}" class="btn btn-sm btn-primary">
                            View
                        </g:link>
                        <g:link controller="location" action="insight" id="${point.id}" class="btn btn-sm btn-success">
                            AI Insight
                        </g:link>
                    </td>
                </tr>
            </g:each>
            </tbody>
        </table>
    </g:if>

    <g:else>
        <div class="alert alert-warning" role="alert">
            No high priority delivery points found.
        </div>
    </g:else>

    <div class="mt-3">
        <g:link controller="location" action="index" class="btn btn-secondary">
            Back to All Locations
        </g:link>
    </div>
</div>
</body>
</html>