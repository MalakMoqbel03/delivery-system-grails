package com.ubs.delivery

import grails.gorm.transactions.Transactional

@Transactional
class LocationService {

    /* Returns a page of all locations ordered by name */
    List<Location> list(params) {
        def max    = params?.max    ? params.int('max')    : 100
        def offset = params?.offset ? params.int('offset') : 0
        Location.executeQuery(
                "select l from Location l order by l.name asc",
                [:],
                [max: max, offset: offset]
        )
    }

    /* Total count of all locations */
    int count() {
        Location.executeQuery("select count(l) from Location l")[0] as int
    }

    Location get(Long id) {
        Location.get(id)
    }

    Location save(Location location) {
        location.save(flush: true, failOnError: true)
    }

    void delete(Long id) {
        Location.get(id)?.delete(flush: true)
    }

    /* All locations sorted by Euclidean distance from origin (0,0) */
    List<Location> getAllSortedByDistance() {
        Location.executeQuery(
                "select l from Location l order by (l.x * l.x + l.y * l.y) asc"
        )
    }

    /* All HIGH-priority delivery points */
    List<DeliveryPoint> getHighPriorityDeliveries() {
        DeliveryPoint.executeQuery(
                "select dp from DeliveryPoint dp where dp.priority = :p order by dp.name asc",
                [p: 'HIGH']
        )
    }

    /* Warehouses that still have room (currentLoad < maxCapacity) */
    List<Warehouse> getWarehousesWithSpace() {
        Warehouse.executeQuery(
                "select w from Warehouse w where w.currentLoad < w.maxCapacity order by w.name asc"
        )
    }

    /*
     * Search used by the navbar live-search and the map pin loader.
     *
     * withCriteria (Criteria API) is used here because the name/code filter
     * is optional — it is only appended when the caller passes a non-blank query.
     * Doing the same with HQL would require messy string concatenation.
     *
     * Returns: list of maps { id, name, code, x, y, type } ready for JSON.
     */
    List<Map> search(String q) {
        def results = Location.withCriteria {
            // Only concrete subtypes — skip plain Location base rows
            or {
                eq('class', Warehouse)
                eq('class', DeliveryPoint)
            }
            // Name/code filter is added only when a term is given
            if (q && q.trim()) {
                or {
                    ilike('name', "%${q.trim()}%")
                    ilike('code', "%${q.trim()}%")
                }
            }
            order('name', 'asc')
            maxResults(50)
        }

        results.collect { loc ->
            [
                    id  : loc.id,
                    name: loc.name,
                    code: loc.code,
                    x   : loc.x,
                    y   : loc.y,
                    type: loc.class.simpleName
            ]
        }
    }

    /*
     * Generates a plain-text insight for a location.
     * Logs the result to AIQueryLog for the history view.
     *
     * Uses instanceof to branch on the concrete type:
     *   DeliveryPoint → urgency advice based on priority
     *   Warehouse     → capacity status
     *   Location      → generic coordinates message
     */
    String getAIInsight(Location location) {
        String result
        if (location instanceof DeliveryPoint) {
            DeliveryPoint dp = (DeliveryPoint) location
            String timeAdvice = dp.priority == 'HIGH'   ? 'Schedule immediately — this is urgent.'
                    : dp.priority == 'MEDIUM' ? 'Deliver within the next 24 hours.'
                    :                           'Can be scheduled at your convenience.'
            result = "Delivery to ${dp.deliveryArea}: ${timeAdvice}"
        } else if (location instanceof Warehouse) {
            Warehouse wh = (Warehouse) location
            result = "Warehouse ${wh.name} ${wh.hasSpace() ? 'has space available' : 'is FULL'} (${wh.currentLoad}/${wh.maxCapacity})."
        } else {
            result = "General location ${location.name} at (${location.x}, ${location.y})."
        }

        new AIQueryLog(
                locationCode: location.code,
                locationName: location.name,
                queryType   : location.class.simpleName,
                aiResponse  : result
        ).save(flush: true, failOnError: true)

        return result
    }
}
