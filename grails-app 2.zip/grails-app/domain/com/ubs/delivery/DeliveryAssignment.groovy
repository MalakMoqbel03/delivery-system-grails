package com.ubs.delivery

class DeliveryAssignment {


    String  status      // PENDING, IN_TRANSIT, or DELIVERED

    // Auto-set to now when the assignment is created
    Date assignedAt  = new Date()

    static belongsTo = [ warehouse : Warehouse,
                         deliveryPoint: DeliveryPoint
    ]

    static constraints = {
        status      nullable: false, inList: ['PENDING', 'IN_TRANSIT', 'DELIVERED']
        assignedAt  nullable: false
        warehouse   nullable: false
        deliveryPoint nullable: false
    }

    @Override
    String toString() {
        return "${warehouse?.name} → ${deliveryPoint?.name} [${status}]"
    }
}
